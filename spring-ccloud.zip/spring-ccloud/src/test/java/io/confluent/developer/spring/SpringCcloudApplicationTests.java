package io.confluent.developer.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCcloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
